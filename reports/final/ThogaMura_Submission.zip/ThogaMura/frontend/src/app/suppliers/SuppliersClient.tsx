"use client";

import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { fetchProducts, fetchSupplierAvailability } from "@/lib/api/inventory";
import { formatFullDateTime, formatUnits } from "@/lib/formatters";
import { safeReturnTo } from "@/lib/returnTo";
import type { SupplierAvailability, SupplierStatus } from "@/lib/types/inventory";
import { isSku } from "@/lib/reservationAttempt";
import { useWarehouseQuery } from "@/lib/useWarehouseQuery";
import { Freshness, primaryAction, secondaryAction, surface, WorkspaceHeading } from "@/components/Workspace";

const outcomes: Record<SupplierStatus, string> = {
  AVAILABLE: "Availability reported",
  UNKNOWN: "SKU unknown to supplier",
  UNAVAILABLE: "Supplier unavailable",
  SUPPLIER_UNAVAILABLE: "Supplier unavailable",
  SUPPLIER_TIMEOUT: "Supplier timed out",
  WAREHOUSE_UNAVAILABLE: "Warehouse unavailable",
  WAREHOUSE_TIMEOUT: "Warehouse did not respond",
  INVALID_SUPPLIER_RESPONSE: "Supplier response could not be verified",
  INVALID_REQUEST: "Check the SKU",
  GATEWAY_UNAVAILABLE: "Gateway unavailable",
  GATEWAY_TIMEOUT: "Gateway did not respond",
  INQUIRY_FAILED: "Inquiry failed",
};

function SupplierInquiry({ initialSku, back }: { initialSku: string; back: string }) {
  const [sku, setSku] = useState(initialSku);
  const [lookup, setLookup] = useState<string | null>(null);
  const [result, setResult] = useState<SupplierAvailability | null>(null);
  const [validation, setValidation] = useState(false);
  const revision = useRef(0);
  const invalidate = useCallback(() => { revision.current++; }, []);
  const products = useWarehouseQuery(fetchProducts);
  const product = products.data?.find((row) => row.sku === sku.trim());

  const inquire = useCallback(async (requested: string) => {
    const normalized = requested.trim();
    if (!isSku(normalized)) {
      setValidation(true);
      return;
    }
    const ticket = ++revision.current;
    setLookup(normalized);
    setResult(null);
    setValidation(false);
    try {
      const supplier = await fetchSupplierAvailability(normalized);
      if (ticket === revision.current) setResult(supplier);
    } catch {
      if (ticket === revision.current) setResult({ sku: normalized, status: "INQUIRY_FAILED" });
    } finally {
      if (ticket === revision.current) setLookup(null);
    }
  }, []);

  useEffect(() => {
    const timer = initialSku ? setTimeout(() => void inquire(initialSku), 0) : undefined;
    return () => {
      clearTimeout(timer);
      invalidate();
    };
  }, [initialSku, inquire, invalidate]);

  function edit(value: string) {
    revision.current++;
    setSku(value);
    setLookup(null);
    setResult(null);
    setValidation(false);
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    void inquire(sku);
  }

  return (
    <div className="space-y-6">
      <WorkspaceHeading title="Supplier availability" description="Check what the supplier reports for an item before following up manually."
        action={<Link href={back} className={secondaryAction}>Back to inventory</Link>} />

      <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
        <form onSubmit={submit} className={`${surface} space-y-4 p-5`}>
          <label htmlFor="supplier-sku" className="block text-sm font-semibold">Product SKU</label>
          <input id="supplier-sku" type="search" list="supplier-products" value={sku} onChange={(event) => edit(event.target.value)}
            className="min-h-11 w-full rounded-lg border border-slate-300 px-3 text-sm"
            aria-describedby={validation ? "supplier-error" : "supplier-help"} aria-invalid={validation} />
          <datalist id="supplier-products">
            {products.data?.map((item) => <option key={item.sku} value={item.sku}>{item.name}</option>)}
          </datalist>
          {validation
            ? <p id="supplier-error" role="alert" className="text-sm text-rose-900">Enter a SKU with 1–64 letters, digits, hyphens or underscores.</p>
            : <p id="supplier-help" className="text-sm text-slate-600">Choose a warehouse item or enter its exact SKU.</p>}
          <button type="submit" className={primaryAction} disabled={lookup !== null}>{lookup ? "Checking…" : "Check availability"}</button>
          <details className="border-t border-slate-200 pt-4 text-sm">
            <summary className="cursor-pointer font-semibold text-slate-700">Supplier demo scenarios</summary>
            <div className="mt-3 flex flex-wrap gap-2">
              {[["ITEM-008", "Available"], ["ITEM-ZERO", "Confirmed zero"], ["ITEM-UNKNOWN", "Unknown SKU"], ["ITEM-OUTAGE", "Outage"], ["ITEM-MALFORMED", "Malformed response"]].map(([item, label]) => (
                <button key={item} type="button" className={secondaryAction} onClick={() => { edit(item); void inquire(item); }}>{label}</button>
              ))}
            </div>
          </details>
        </form>

        <section className={`${surface} space-y-2 p-5`} aria-label="Warehouse stock">
          <h2 className="font-semibold">Warehouse stock</h2>
          {product ? (
            <><p className="text-2xl font-semibold tabular-nums">{formatUnits(product.available)} available</p><p className="text-sm text-slate-700">{product.name} · {product.sku}</p></>
          ) : <p className="text-sm text-slate-600">{sku.trim() ? "No balance for this SKU in the loaded catalog." : "Choose a SKU to see its warehouse balance."}</p>}
          <Freshness {...products} />
        </section>
      </div>

      <section className={`${surface} space-y-2 p-5`} aria-label="Supplier result" aria-live="polite">
        <h2 className="text-lg font-semibold">Supplier result</h2>
        {lookup && <p className="text-sm text-slate-600">Checking {lookup}…</p>}
        {!result && !lookup && <p className="text-sm text-slate-600">Run an inquiry to see the supplier’s reported stock.</p>}
        {result && (
          <>
            <p className="text-sm font-semibold text-slate-700">{result.sku} · {outcomes[result.status]}</p>
            {result.status === "AVAILABLE" ? (
              <>
                <p className="text-2xl font-semibold tabular-nums text-slate-950">{formatUnits(result.reportedQuantity)} reported</p>
                <p className="text-sm text-slate-700">{result.supplier} · {result.source === "MOCK_SUPPLIER" ? "Demo supplier" : result.source} · Checked {formatFullDateTime(result.checkedAt)}</p>
                {result.estimatedRestockDays !== undefined && <p className="text-sm text-slate-600">Supplier restock estimate {result.estimatedRestockDays} days</p>}
              </>
            ) : (
              <>
                <p className="text-sm text-slate-700">{result.message ?? "No supplier quantity was confirmed."}</p>
                <button type="button" className={secondaryAction} onClick={() => void inquire(result.sku)}>Check again</button>
              </>
            )}
          </>
        )}
      </section>
    </div>
  );
}

export function SuppliersClient() {
  const params = useSearchParams();
  const initialSku = params.get("sku") ?? "";
  return <SupplierInquiry key={initialSku} initialSku={initialSku} back={safeReturnTo(params.get("returnTo"))} />;
}
